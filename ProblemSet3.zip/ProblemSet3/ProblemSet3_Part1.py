/*-PS3: Code Block 1--*/

mountain = "Denali"
nickname = 'Mt. McKinley'
elevation == 20322 

print (mountain + ", formerly known as "" + nickname + ",)
print ()"is " + elevation + '' above sea level.' )